﻿namespace KurtisMcCammon1
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.SettingsMenu = new System.Windows.Forms.TabControl();
            this.TimeSize = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DeadCellColor = new System.Windows.Forms.Button();
            this.LivingCellColor = new System.Windows.Forms.Button();
            this.Color = new System.Windows.Forms.TabPage();
            this.LivingFontColor = new System.Windows.Forms.Button();
            this.DyingFontColor = new System.Windows.Forms.Button();
            this.BirthFontColor = new System.Windows.Forms.Button();
            this.SettingsMenu.SuspendLayout();
            this.TimeSize.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(360, 415);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 0;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // Apply
            // 
            this.Apply.Location = new System.Drawing.Point(279, 415);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(75, 23);
            this.Apply.TabIndex = 1;
            this.Apply.Text = "Apply";
            this.Apply.UseVisualStyleBackColor = true;
            // 
            // SettingsMenu
            // 
            this.SettingsMenu.Controls.Add(this.TimeSize);
            this.SettingsMenu.Controls.Add(this.Color);
            this.SettingsMenu.Cursor = System.Windows.Forms.Cursors.Default;
            this.SettingsMenu.Location = new System.Drawing.Point(12, 12);
            this.SettingsMenu.Name = "SettingsMenu";
            this.SettingsMenu.SelectedIndex = 0;
            this.SettingsMenu.Size = new System.Drawing.Size(432, 397);
            this.SettingsMenu.TabIndex = 2;
            // 
            // TimeSize
            // 
            this.TimeSize.Controls.Add(this.groupBox2);
            this.TimeSize.Controls.Add(this.groupBox1);
            this.TimeSize.Location = new System.Drawing.Point(4, 22);
            this.TimeSize.Name = "TimeSize";
            this.TimeSize.Padding = new System.Windows.Forms.Padding(3);
            this.TimeSize.Size = new System.Drawing.Size(424, 371);
            this.TimeSize.TabIndex = 0;
            this.TimeSize.Text = "Color";
            this.TimeSize.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BirthFontColor);
            this.groupBox2.Controls.Add(this.DyingFontColor);
            this.groupBox2.Controls.Add(this.LivingFontColor);
            this.groupBox2.Location = new System.Drawing.Point(6, 162);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(415, 203);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Text Color";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DeadCellColor);
            this.groupBox1.Controls.Add(this.LivingCellColor);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(415, 150);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cell Color";
            // 
            // DeadCellColor
            // 
            this.DeadCellColor.Location = new System.Drawing.Point(7, 96);
            this.DeadCellColor.Name = "DeadCellColor";
            this.DeadCellColor.Size = new System.Drawing.Size(75, 23);
            this.DeadCellColor.TabIndex = 1;
            this.DeadCellColor.Text = "Dead Cell";
            this.DeadCellColor.UseVisualStyleBackColor = true;
            // 
            // LivingCellColor
            // 
            this.LivingCellColor.Location = new System.Drawing.Point(6, 35);
            this.LivingCellColor.Name = "LivingCellColor";
            this.LivingCellColor.Size = new System.Drawing.Size(75, 23);
            this.LivingCellColor.TabIndex = 0;
            this.LivingCellColor.Text = "Living Cell";
            this.LivingCellColor.UseVisualStyleBackColor = true;
            // 
            // Color
            // 
            this.Color.Location = new System.Drawing.Point(4, 22);
            this.Color.Name = "Color";
            this.Color.Padding = new System.Windows.Forms.Padding(3);
            this.Color.Size = new System.Drawing.Size(424, 371);
            this.Color.TabIndex = 1;
            this.Color.Text = "Time & Size";
            this.Color.UseVisualStyleBackColor = true;
            // 
            // LivingFontColor
            // 
            this.LivingFontColor.Location = new System.Drawing.Point(7, 42);
            this.LivingFontColor.Name = "LivingFontColor";
            this.LivingFontColor.Size = new System.Drawing.Size(75, 23);
            this.LivingFontColor.TabIndex = 0;
            this.LivingFontColor.Text = "Living Cell";
            this.LivingFontColor.UseVisualStyleBackColor = true;
            // 
            // DyingFontColor
            // 
            this.DyingFontColor.Location = new System.Drawing.Point(7, 97);
            this.DyingFontColor.Name = "DyingFontColor";
            this.DyingFontColor.Size = new System.Drawing.Size(75, 23);
            this.DyingFontColor.TabIndex = 1;
            this.DyingFontColor.Text = "Dying Font";
            this.DyingFontColor.UseVisualStyleBackColor = true;
            // 
            // BirthFontColor
            // 
            this.BirthFontColor.Location = new System.Drawing.Point(7, 152);
            this.BirthFontColor.Name = "BirthFontColor";
            this.BirthFontColor.Size = new System.Drawing.Size(75, 23);
            this.BirthFontColor.TabIndex = 2;
            this.BirthFontColor.Text = "Birth Font";
            this.BirthFontColor.UseVisualStyleBackColor = true;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 450);
            this.Controls.Add(this.SettingsMenu);
            this.Controls.Add(this.Apply);
            this.Controls.Add(this.Cancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Settings";
            this.Text = "Settings";
            this.SettingsMenu.ResumeLayout(false);
            this.TimeSize.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.TabControl SettingsMenu;
        private System.Windows.Forms.TabPage TimeSize;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage Color;
        private System.Windows.Forms.Button DeadCellColor;
        private System.Windows.Forms.Button LivingCellColor;
        private System.Windows.Forms.Button BirthFontColor;
        private System.Windows.Forms.Button DyingFontColor;
        private System.Windows.Forms.Button LivingFontColor;
    }
}