﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KurtisMcCammon1
{
    class UserSettings
    {
        //true for toroidal false for finite
        bool torofinite = false;

        //font colors
        //Living color
        public Color LivingFontColor { get; private set; }
        //Coming to Life
        public Color BirthFontColor { get; private set; }
        //Dead
        public Color DeadFontColor { get; private set; }
        //Dieing
        public Color DyingFontColor { get; private set; }

        //cell colors
        //background
        public Color Background { get; private set; }
        //cell
        public Color CellColor { get; private set; }
        //grid
        public Color GridLines { get; private set; }

        //tick speed
        public int TickSpeed { get; private set; }
        //width of universe
        public int UniverseWidth { get; private set; }
        //height of universe
        public int UniverseHeight { get; private set; }

        //Default settings
        public UserSettings()
        {
            torofinite = false;

            LivingFontColor = Color.Green;
            BirthFontColor = Color.PeachPuff;
            DeadFontColor = Color.Gray;
            DyingFontColor = Color.DarkRed;

            Background = Color.White;
            CellColor = Color.MediumPurple;
            GridLines = Color.Orange;

            TickSpeed = 100;
            UniverseWidth = 10;
            UniverseHeight = 10;
        }
    }
}
